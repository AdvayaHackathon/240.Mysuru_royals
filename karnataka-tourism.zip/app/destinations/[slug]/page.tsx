import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { notFound } from "next/navigation"

// This would come from a database in a real application
const destinationsData = {
  mysuru: {
    name: "Mysuru",
    title: "Mysuru - The Cultural Capital",
    heroImage: "/placeholder.svg?height=600&width=1200",
    description:
      "Mysuru (formerly known as Mysore) is a city in India's southwestern Karnataka state. It was the capital of the Kingdom of Mysore from 1399 to 1947. The city is famous for its well-preserved heritage buildings and palaces, including the magnificent Mysore Palace.",
    highlights: [
      {
        title: "Mysore Palace",
        description:
          "The official residence of the Wadiyar dynasty, this Indo-Saracenic marvel is one of the largest palaces in India. On Sundays and during the Dasara festival, the palace is illuminated with thousands of lights.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Chamundi Hills",
        description:
          "A 1000-step climb leads to the Chamundeshwari Temple atop the hills. The famous Nandi statue, carved from a single stone, is located on the way to the temple.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Devaraja Market",
        description:
          "A vibrant traditional market that offers a glimpse into local life. Famous for its flower stalls, fresh produce, and sandalwood products.",
        image: "/placeholder.svg?height=300&width=400",
      },
    ],
    culture: {
      festivals: ["Dasara (Navaratri)", "Mysuru Yoga Festival"],
      cuisine: ["Mysore Pak", "Mysore Masala Dosa", "Mysore Bonda"],
      arts: ["Mysore Painting", "Mysore Silk", "Mysore Sandalwood Carving"],
    },
    itinerary: [
      {
        day: "Day 1",
        activities: [
          "Visit Mysore Palace in the morning",
          "Explore Devaraja Market",
          "Evening visit to Brindavan Gardens with musical fountain show",
        ],
      },
      {
        day: "Day 2",
        activities: [
          "Morning trip to Chamundi Hills and temple",
          "Visit Mysore Zoo",
          "Evening cultural performance at Kalamandira",
        ],
      },
      {
        day: "Day 3",
        activities: [
          "Visit St. Philomena's Church",
          "Explore Railway Museum",
          "Shopping for Mysore Silk and sandalwood souvenirs",
        ],
      },
    ],
  },
  hampi: {
    name: "Hampi",
    title: "Hampi - The Ancient Wonder",
    heroImage: "/placeholder.svg?height=600&width=1200",
    description:
      "Hampi is an ancient village in Karnataka, famous for its ruins that date back to the Vijayanagara Empire. This UNESCO World Heritage Site features stunning temples, royal complexes, and natural landscapes that transport visitors back in time.",
    highlights: [
      {
        title: "Virupaksha Temple",
        description:
          "One of the oldest functioning temples in India, dedicated to Lord Shiva. The temple features intricate carvings and a 160-foot high gopuram (tower).",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Vittala Temple Complex",
        description:
          "Home to the famous Stone Chariot and musical pillars. The craftsmanship of this temple complex showcases the architectural brilliance of the Vijayanagara Empire.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Hampi Bazaar",
        description:
          "A 1-km long ancient market street with pavilions where traders once sold jewels and textiles. Today, it's a vibrant area with small shops and cafes.",
        image: "/placeholder.svg?height=300&width=400",
      },
    ],
    culture: {
      festivals: ["Hampi Utsav", "Purandaradasa Aradhana"],
      cuisine: ["Jolada Rotti", "Bisi Bele Bath", "Mirchi Bajji"],
      arts: ["Stone Carving", "Traditional Music", "Lambani Embroidery"],
    },
    itinerary: [
      {
        day: "Day 1",
        activities: [
          "Explore Virupaksha Temple and Hampi Bazaar",
          "Visit Hemakuta Hill temples",
          "Sunset at Matanga Hill",
        ],
      },
      {
        day: "Day 2",
        activities: [
          "Visit Vittala Temple and Stone Chariot",
          "Explore Royal Enclosure and Queen's Bath",
          "Evening coracle ride on Tungabhadra River",
        ],
      },
      {
        day: "Day 3",
        activities: [
          "Visit Achyutaraya Temple and Courtesan's Street",
          "Explore Hazara Rama Temple",
          "Visit the Archaeological Museum",
        ],
      },
    ],
  },
  coorg: {
    name: "Coorg",
    title: "Coorg - Scotland of India",
    heroImage: "/placeholder.svg?height=600&width=1200",
    description:
      "Coorg (Kodagu) is a rural district in Karnataka known for its coffee plantations, lush landscapes, and the warrior Kodava people. With misty hills, waterfalls, and a pleasant climate, it's often called the 'Scotland of India'.",
    highlights: [
      {
        title: "Abbey Falls",
        description:
          "A magnificent waterfall nestled amidst coffee plantations and spice estates. The roaring waters cascade from a height of 70 feet, creating a mesmerizing spectacle.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Raja's Seat",
        description:
          "A seasonal garden with a pavilion, offering panoramic views of the valleys and paddy fields. The sunset views from here are spectacular.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Talakaveri",
        description:
          "The birthplace of the River Cauvery, located on the slopes of Brahmagiri Hills. The site has a temple and a holy tank with steps leading down to it.",
        image: "/placeholder.svg?height=300&width=400",
      },
    ],
    culture: {
      festivals: ["Keil Poldu (Weapons Worship)", "Cauvery Sankramana", "Puttari (Harvest Festival)"],
      cuisine: ["Pandi Curry (Pork Curry)", "Kadambuttu (Rice Dumplings)", "Akki Roti"],
      arts: ["Kodava Folk Dance", "Traditional Kodava Attire", "Bamboo Crafts"],
    },
    itinerary: [
      {
        day: "Day 1",
        activities: ["Visit Abbey Falls", "Explore Raja's Seat for sunset", "Evening walk in Madikeri town"],
      },
      {
        day: "Day 2",
        activities: [
          "Visit Talakaveri and Bhagamandala",
          "Explore Dubare Elephant Camp",
          "Evening coffee plantation tour",
        ],
      },
      {
        day: "Day 3",
        activities: [
          "Trek to Tadiandamol Peak",
          "Visit Namdroling Monastery (Golden Temple)",
          "Shopping for coffee and spices",
        ],
      },
    ],
  },
  gokarna: {
    name: "Gokarna",
    title: "Gokarna - Beaches and Temples",
    heroImage: "/placeholder.svg?height=600&width=1200",
    description:
      "Gokarna is a small temple town on the western coast of India in Karnataka. It is an important pilgrimage site for Hindus and has become increasingly popular as a beach destination with pristine beaches and laid-back atmosphere.",
    highlights: [
      {
        title: "Om Beach",
        description:
          "Named for its shape resembling the Om symbol, this beach is one of Gokarna's most famous. The clear waters and golden sands make it perfect for swimming and relaxation.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Mahabaleshwar Temple",
        description:
          "A sacred Hindu temple housing the Atmalinga of Lord Shiva. The temple is an important pilgrimage site and features traditional Dravidian architecture.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Paradise Beach",
        description:
          "Also known as Full Moon Beach, this secluded beach is accessible only by boat or a challenging trek, offering pristine sands and crystal-clear waters.",
        image: "/placeholder.svg?height=300&width=400",
      },
    ],
    culture: {
      festivals: ["Shivaratri", "Ganesh Chaturthi", "Kartik Purnima"],
      cuisine: ["Fish Curry", "Neer Dosa", "Kori Rotti"],
      arts: ["Temple Carvings", "Yakshagana Performances", "Coastal Handicrafts"],
    },
    itinerary: [
      {
        day: "Day 1",
        activities: [
          "Visit Mahabaleshwar Temple in the morning",
          "Explore Gokarna Beach and town",
          "Evening sunset at Kudle Beach",
        ],
      },
      {
        day: "Day 2",
        activities: ["Trek to Om Beach", "Water activities and relaxation", "Visit nearby Mirjan Fort"],
      },
      {
        day: "Day 3",
        activities: [
          "Boat trip to Paradise Beach and Half Moon Beach",
          "Beach hopping and swimming",
          "Evening yoga session by the beach",
        ],
      },
    ],
  },
  bengaluru: {
    name: "Bengaluru",
    title: "Bengaluru - The Silicon Valley of India",
    heroImage: "/placeholder.svg?height=600&width=1200",
    description:
      "Bengaluru (formerly Bangalore) is the capital of Karnataka and the center of India's high-tech industry. The city is known for its parks, nightlife, and pleasant climate throughout the year, earning it the nickname 'Garden City'.",
    highlights: [
      {
        title: "Lalbagh Botanical Garden",
        description:
          "A 240-acre garden featuring rare plants, a glass house, and a lake. The garden hosts flower shows during Republic Day and Independence Day celebrations.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Cubbon Park",
        description:
          "A landmark 'lung' area of the city with 300 acres of greenery, containing many neo-classical buildings including the State Central Library and High Court.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Bangalore Palace",
        description:
          "Built in 1887, this palace was inspired by England's Windsor Castle and features Tudor-style architecture with fortified towers and turreted parapets.",
        image: "/placeholder.svg?height=300&width=400",
      },
    ],
    culture: {
      festivals: ["Karaga", "Bengaluru Habba", "Kadalekai Parishe"],
      cuisine: ["Benne Masala Dosa", "Ragi Mudde", "Obbattu"],
      arts: ["Contemporary Art", "Theater", "Carnatic Music"],
    },
    itinerary: [
      {
        day: "Day 1",
        activities: [
          "Visit Lalbagh Botanical Garden",
          "Explore Cubbon Park",
          "Evening at MG Road and Commercial Street for shopping",
        ],
      },
      {
        day: "Day 2",
        activities: [
          "Visit Bangalore Palace",
          "Explore ISKCON Temple",
          "Evening at UB City for luxury shopping and dining",
        ],
      },
      {
        day: "Day 3",
        activities: ["Day trip to Nandi Hills", "Visit Innovative Film City", "Experience Bengaluru's nightlife"],
      },
    ],
  },

  chikmagalur: {
    name: "Chikmagalur",
    title: "Chikmagalur - Coffee Land of Karnataka",
    heroImage: "/placeholder.svg?height=600&width=1200",
    description:
      "Chikmagalur is a hill station in Karnataka, known for its coffee plantations, mountains, and lush greenery. It's the birthplace of coffee in India, where coffee was first cultivated in the 17th century.",
    highlights: [
      {
        title: "Mullayanagiri Peak",
        description:
          "The highest peak in Karnataka at 1,930 meters, offering panoramic views of the Western Ghats and trekking opportunities.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Coffee Plantations",
        description:
          "Vast estates where you can learn about coffee cultivation, processing, and enjoy freshly brewed coffee amidst scenic surroundings.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Bhadra Wildlife Sanctuary",
        description:
          "Home to tigers, leopards, elephants, and various bird species. The sanctuary offers wildlife safaris and boating in the Bhadra Reservoir.",
        image: "/placeholder.svg?height=300&width=400",
      },
    ],
    culture: {
      festivals: ["Mahamastakabhisheka", "Huthri", "Coffee Festival"],
      cuisine: ["Akki Rotti", "Kadabu", "Neer Dosa"],
      arts: ["Yakshagana", "Folk Music", "Traditional Crafts"],
    },
    itinerary: [
      {
        day: "Day 1",
        activities: [
          "Visit coffee plantations and participate in coffee tasting",
          "Trek to Mullayanagiri Peak",
          "Evening at Chikmagalur town",
        ],
      },
      {
        day: "Day 2",
        activities: ["Visit Bhadra Wildlife Sanctuary", "Explore Hebbe Falls", "Evening at coffee estate homestay"],
      },
      {
        day: "Day 3",
        activities: [
          "Visit Kemmangundi hill station",
          "Explore Z Point for panoramic views",
          "Shopping for coffee and spices",
        ],
      },
    ],
  },

  badami: {
    name: "Badami",
    title: "Badami - Ancient Cave Temples",
    heroImage: "/placeholder.svg?height=600&width=1200",
    description:
      "Badami (formerly known as Vatapi) was the capital of the early Chalukya dynasty from the 6th to 8th century. Famous for its rock-cut cave temples, Badami is an archaeological treasure with stunning sandstone cliffs and a beautiful artificial lake.",
    highlights: [
      {
        title: "Badami Cave Temples",
        description:
          "Four magnificent cave temples carved out of soft sandstone hills, featuring intricate sculptures of Hindu deities, especially Lord Shiva in various forms.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Agastya Lake",
        description:
          "An ancient man-made lake that adds to the scenic beauty of Badami. The lake is surrounded by temples and monuments, creating a picturesque setting.",
        image: "/placeholder.svg?height=300&width=400",
      },
      {
        title: "Archaeological Museum",
        description:
          "Houses sculptures, inscriptions, and artifacts from the Chalukya period, providing insights into the rich history and artistry of the region.",
        image: "/placeholder.svg?height=300&width=400",
      },
    ],
    culture: {
      festivals: ["Chalukya Utsava", "Banashankari Jatra", "Mallikarjuna Festival"],
      cuisine: ["Jolada Rotti", "Badami Halwa", "Kadubu"],
      arts: ["Stone Carving", "Chalukyan Architecture", "Traditional Crafts"],
    },
    itinerary: [
      {
        day: "Day 1",
        activities: ["Explore Badami Cave Temples", "Visit Agastya Lake", "Evening at Badami Archaeological Museum"],
      },
      {
        day: "Day 2",
        activities: [
          "Day trip to Aihole (ancient temple complex)",
          "Visit Pattadakal UNESCO World Heritage Site",
          "Evening return to Badami",
        ],
      },
      {
        day: "Day 3",
        activities: [
          "Trek to North Fort and Shivalaya temples",
          "Visit Banashankari Temple",
          "Explore local markets for handicrafts",
        ],
      },
    ],
  },
}

export default function DestinationPage({ params }: { params: { slug: string } }) {
  const destination = destinationsData[params.slug as keyof typeof destinationsData]

  if (!destination) {
    notFound()
  }

  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-[60vh] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${destination.heroImage})`,
            filter: "brightness(0.7)",
          }}
        />
        <div className="relative h-full flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">{destination.title}</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto mb-12">
          <p className="text-lg text-gray-700 leading-relaxed">{destination.description}</p>
        </div>

        <Tabs defaultValue="highlights" className="mb-12">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="highlights">Highlights</TabsTrigger>
            <TabsTrigger value="culture">Cultural Elements</TabsTrigger>
            <TabsTrigger value="itinerary">Suggested Itinerary</TabsTrigger>
            <TabsTrigger value="practical">Practical Info</TabsTrigger>
          </TabsList>

          {/* Highlights Tab */}
          <TabsContent value="highlights" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {destination.highlights.map((highlight, index) => (
                <Card key={index}>
                  <div className="h-48 overflow-hidden">
                    <img
                      src={highlight.image || "/placeholder.svg"}
                      alt={highlight.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="text-xl font-bold mb-2">{highlight.title}</h3>
                    <p className="text-gray-600">{highlight.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Culture Tab */}
          <TabsContent value="culture" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-orange-600">Festivals</h3>
                  <ul className="space-y-2">
                    {destination.culture.festivals.map((festival, index) => (
                      <li key={index} className="flex items-start">
                        <span className="inline-block w-2 h-2 rounded-full bg-orange-500 mt-2 mr-2"></span>
                        <span>{festival}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-green-600">Cuisine</h3>
                  <ul className="space-y-2">
                    {destination.culture.cuisine.map((item, index) => (
                      <li key={index} className="flex items-start">
                        <span className="inline-block w-2 h-2 rounded-full bg-green-500 mt-2 mr-2"></span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-blue-600">Arts & Crafts</h3>
                  <ul className="space-y-2">
                    {destination.culture.arts.map((art, index) => (
                      <li key={index} className="flex items-start">
                        <span className="inline-block w-2 h-2 rounded-full bg-blue-500 mt-2 mr-2"></span>
                        <span>{art}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Itinerary Tab */}
          <TabsContent value="itinerary" className="mt-6">
            <div className="space-y-6">
              {destination.itinerary.map((day, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4">{day.day}</h3>
                    <ul className="space-y-2">
                      {day.activities.map((activity, actIndex) => (
                        <li key={actIndex} className="flex items-start">
                          <span className="inline-block w-6 h-6 rounded-full bg-orange-500 text-white flex items-center justify-center mr-3 flex-shrink-0">
                            {actIndex + 1}
                          </span>
                          <span>{activity}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Practical Info Tab */}
          <TabsContent value="practical" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4">How to Reach</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-bold text-gray-700">By Air</h4>
                      <p className="text-gray-600">
                        {destination.name === "Mysuru"
                          ? "Mysuru Airport has limited flights. Bengaluru International Airport (170 km) is the nearest major airport."
                          : destination.name === "Hampi"
                            ? "Hubli Airport (143 km) and Bellary Airport (60 km) are the nearest airports."
                            : destination.name === "Coorg"
                              ? "Mangalore International Airport (135 km) is the nearest airport to Coorg."
                              : destination.name === "Gokarna"
                                ? "Dabolim Airport in Goa (140 km) is the nearest airport."
                                : destination.name === "Bengaluru"
                                  ? "Kempegowda International Airport Bengaluru (BLR) is well-connected to major cities worldwide."
                                  : destination.name === "Chikmagalur"
                                    ? "Mangalore International Airport (IXE) is the nearest airport, located about 150 km away."
                                    : "Hubli Airport (HBX) is the nearest airport, located approximately 200 km from Badami."}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-700">By Train</h4>
                      <p className="text-gray-600">
                        {destination.name === "Mysuru"
                          ? "Mysuru Railway Station is well-connected to major cities like Bengaluru, Chennai, and Mumbai."
                          : destination.name === "Hampi"
                            ? "Hospet Junction (13 km) is the nearest railway station to Hampi."
                            : destination.name === "Coorg"
                              ? "Mysuru Railway Station (120 km) is the nearest major railway station to Coorg."
                              : destination.name === "Gokarna"
                                ? "Gokarna Road Railway Station is the nearest station, but some trains stop at Ankola (20 km) or Kumta (35 km)."
                                : destination.name === "Bengaluru"
                                  ? "Bengaluru City Railway Station (SBC) is a major railway hub with connections to all major cities in India."
                                  : destination.name === "Chikmagalur"
                                    ? "Chikmagalur Railway Station (CMGR) has limited connectivity. The nearest major railway station is Kadur (DRU), about 40 km away."
                                    : "Badami Railway Station (BDM) is well-connected to major cities in Karnataka and neighboring states."}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-700">By Road</h4>
                      <p className="text-gray-600">
                        {destination.name === "Mysuru"
                          ? "Well-connected by road to Bengaluru (140 km), Coorg (120 km), and Ooty (130 km)."
                          : destination.name === "Hampi"
                            ? "Connected by road to Hospet (13 km), Bengaluru (350 km), and Goa (330 km)."
                            : destination.name === "Coorg"
                              ? "Connected by road to Mysuru (120 km), Bengaluru (250 km), and Mangalore (135 km)."
                              : destination.name === "Gokarna"
                                ? "Connected by road to major cities in Karnataka and Goa. Buses and taxis are available from nearby towns."
                                : destination.name === "Bengaluru"
                                  ? "Well-connected by national highways to major cities in South India. Excellent bus services are available."
                                  : destination.name === "Chikmagalur"
                                    ? "Accessible by road from Bengaluru (240 km), Mangalore (150 km), and other major cities in Karnataka."
                                    : "Connected by road to major cities in Karnataka and Maharashtra. Regular bus services are available from Bengaluru, Hubli, and Belgaum."}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4">Best Time to Visit</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-bold text-gray-700">Peak Season</h4>
                      <p className="text-gray-600">
                        {destination.name === "Mysuru"
                          ? "September to March, especially during Dasara festival (October)."
                          : destination.name === "Hampi"
                            ? "October to March when the weather is pleasant and ideal for exploration."
                            : destination.name === "Coorg"
                              ? "October to March when the weather is cool and pleasant."
                              : destination.name === "Gokarna"
                                ? "October to March when the weather is pleasant and dry."
                                : destination.name === "Bengaluru"
                                  ? "September to February when the weather is pleasant and ideal for outdoor activities."
                                  : destination.name === "Chikmagalur"
                                    ? "September to May when the weather is pleasant for trekking and sightseeing."
                                    : "October to March when the weather is cool and dry, making it ideal for exploring the cave temples."}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-700">Weather</h4>
                      <p className="text-gray-600">
                        {destination.name === "Mysuru"
                          ? "Moderate climate throughout the year. Summers (March-June) can be warm."
                          : destination.name === "Hampi"
                            ? "Hot summers (March-June), monsoon (July-September), and pleasant winters (October-February)."
                            : destination.name === "Coorg"
                              ? "Cool climate throughout the year. Monsoon (June-September) brings heavy rainfall."
                              : destination.name === "Gokarna"
                                ? "Tropical climate. Hot and humid summers (March-May), monsoon (June-September), and mild winters (October-February)."
                                : destination.name === "Bengaluru"
                                  ? "Moderate climate throughout the year. Summers (March-May) are warm, and monsoons (June-September) bring moderate rainfall."
                                  : destination.name === "Chikmagalur"
                                    ? "Cool and pleasant climate throughout the year. Monsoon (June-September) brings heavy rainfall."
                                    : "Hot summers (March-May), monsoon (June-September), and pleasant winters (October-February)."}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-700">Local Transportation</h4>
                      <p className="text-gray-600">
                        {destination.name === "Mysuru"
                          ? "City buses, auto-rickshaws, and taxis are readily available."
                          : destination.name === "Hampi"
                            ? "Auto-rickshaws, bicycles for rent, and coracle boats for river crossings."
                            : destination.name === "Coorg"
                              ? "Local taxis and private vehicles are the best options as public transport is limited."
                              : destination.name === "Gokarna"
                                ? "Auto-rickshaws are the primary mode of transport. Scooters and bicycles are available for rent."
                                : destination.name === "Bengaluru"
                                  ? "BMTC buses, metro, auto-rickshaws, taxis, and ride-sharing services are widely available."
                                  : destination.name === "Chikmagalur"
                                    ? "Local taxis and private vehicles are the best options as public transport is limited."
                                    : "Auto-rickshaws and taxis are available for local transport. Renting a car is a good option for exploring nearby sites."}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Budget Planner CTA */}
        <div className="bg-orange-50 p-8 rounded-lg text-center mb-12">
          <h2 className="text-2xl font-bold mb-4">Plan Your Trip to {destination.name}</h2>
          <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
            Use our dynamic budget planner to estimate costs for your {destination.name} adventure, including
            accommodation, transportation, and activities.
          </p>
          <Link href="/budget-planner">
            <Button size="lg" className="bg-orange-500 hover:bg-orange-600">
              Plan Your Budget
            </Button>
          </Link>
        </div>

        {/* Nearby Destinations */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Nearby Destinations</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {Object.entries(destinationsData)
              .filter(([key]) => key !== params.slug)
              .slice(0, 3)
              .map(([key, value]) => (
                <Link href={`/destinations/${key}`} key={key}>
                  <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="h-40 overflow-hidden">
                      <img
                        src={value.heroImage || "/placeholder.svg"}
                        alt={value.name}
                        className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="text-xl font-bold">{value.name}</h3>
                    </CardContent>
                  </Card>
                </Link>
              ))}
          </div>
        </div>
      </div>
    </div>
  )
}
