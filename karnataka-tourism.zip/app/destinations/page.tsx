import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

const destinations = [
  {
    id: "mysuru",
    name: "Mysuru",
    image: "/placeholder.svg?height=300&width=400",
    description: "The cultural capital with the magnificent Mysore Palace",
    category: "heritage",
  },
  {
    id: "hampi",
    name: "Hampi",
    image: "/placeholder.svg?height=300&width=400",
    description: "UNESCO World Heritage Site with ancient ruins",
    category: "heritage",
  },
  {
    id: "coorg",
    name: "Coorg",
    image: "/placeholder.svg?height=300&width=400",
    description: "Lush green hills and coffee plantations",
    category: "nature",
  },
  {
    id: "gokarna",
    name: "Gokarna",
    image: "/placeholder.svg?height=300&width=400",
    description: "Pristine beaches and spiritual temples",
    category: "beach",
  },
  {
    id: "chikmagalur",
    name: "Chikmagalur",
    image: "/placeholder.svg?height=300&width=400",
    description: "Coffee estates and beautiful mountain ranges",
    category: "nature",
  },
  {
    id: "badami",
    name: "Badami",
    image: "/placeholder.svg?height=300&width=400",
    description: "Ancient cave temples and historical sites",
    category: "heritage",
  },
  {
    id: "bengaluru",
    name: "Bengaluru",
    image: "/placeholder.svg?height=300&width=400",
    description: "The Silicon Valley of India with gardens and tech hubs",
    category: "urban",
  },
  {
    id: "belur-halebidu",
    name: "Belur & Halebidu",
    image: "/placeholder.svg?height=300&width=400",
    description: "Twin towns famous for Hoysala architecture",
    category: "heritage",
  },
  {
    id: "jog-falls",
    name: "Jog Falls",
    image: "/placeholder.svg?height=300&width=400",
    description: "One of the highest waterfalls in India",
    category: "nature",
  },
  {
    id: "murudeshwar",
    name: "Murudeshwar",
    image: "/placeholder.svg?height=300&width=400",
    description: "Coastal town with the world's second-tallest Shiva statue",
    category: "beach",
  },
  {
    id: "udupi",
    name: "Udupi",
    image: "/placeholder.svg?height=300&width=400",
    description: "Temple town famous for its cuisine and Krishna Temple",
    category: "heritage",
  },
  {
    id: "dandeli",
    name: "Dandeli",
    image: "/placeholder.svg?height=300&width=400",
    description: "Wildlife sanctuary and adventure sports destination",
    category: "nature",
  },
]

export default function DestinationsPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 text-center">Explore Karnataka's Destinations</h1>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="grid grid-cols-5 max-w-2xl mx-auto">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="heritage">Heritage</TabsTrigger>
          <TabsTrigger value="nature">Nature</TabsTrigger>
          <TabsTrigger value="beach">Beaches</TabsTrigger>
          <TabsTrigger value="urban">Urban</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.map((destination) => (
              <DestinationCard key={destination.id} destination={destination} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="heritage" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations
              .filter((d) => d.category === "heritage")
              .map((destination) => (
                <DestinationCard key={destination.id} destination={destination} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="nature" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations
              .filter((d) => d.category === "nature")
              .map((destination) => (
                <DestinationCard key={destination.id} destination={destination} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="beach" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations
              .filter((d) => d.category === "beach")
              .map((destination) => (
                <DestinationCard key={destination.id} destination={destination} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="urban" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations
              .filter((d) => d.category === "urban")
              .map((destination) => (
                <DestinationCard key={destination.id} destination={destination} />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function DestinationCard({ destination }: { destination: (typeof destinations)[0] }) {
  return (
    <Link href={`/destinations/${destination.id}`}>
      <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full">
        <div className="h-48 overflow-hidden">
          <img
            src={destination.image || "/placeholder.svg"}
            alt={destination.name}
            className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
          />
        </div>
        <CardContent className="p-4">
          <h3 className="text-xl font-bold mb-2">{destination.name}</h3>
          <p className="text-gray-600">{destination.description}</p>
          <div className="mt-4">
            <span
              className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                destination.category === "heritage"
                  ? "bg-amber-100 text-amber-800"
                  : destination.category === "nature"
                    ? "bg-green-100 text-green-800"
                    : destination.category === "beach"
                      ? "bg-blue-100 text-blue-800"
                      : "bg-purple-100 text-purple-800"
              }`}
            >
              {destination.category.charAt(0).toUpperCase() + destination.category.slice(1)}
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
