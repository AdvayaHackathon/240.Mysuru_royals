"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { useLanguage } from "@/context/language-context"

export default function RecommendationsPage() {
  const { t } = useLanguage()
  const [query, setQuery] = useState("")
  const [budget, setBudget] = useState([5000])
  const [days, setDays] = useState([3])
  const [interests, setInterests] = useState<string[]>([])
  const [recommendations, setRecommendations] = useState<any[] | null>(null)
  const [loading, setLoading] = useState(false)

  const interestOptions = [
    { id: "heritage", label: "Heritage & History" },
    { id: "nature", label: "Nature & Wildlife" },
    { id: "adventure", label: "Adventure" },
    { id: "spiritual", label: "Spiritual" },
    { id: "food", label: "Culinary Experiences" },
    { id: "photography", label: "Photography" },
  ]

  const toggleInterest = (interest: string) => {
    setInterests((prev) => (prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]))
  }

  const getRecommendations = () => {
    setLoading(true)

    // Simulate AI recommendation generation
    setTimeout(() => {
      // This would be replaced with actual AI recommendations in production
      const mockRecommendations = [
        {
          title: "Heritage Tour of Mysuru and Hampi",
          description:
            "Explore the royal heritage of Mysuru Palace and the ancient ruins of Hampi, a UNESCO World Heritage site.",
          days: 4,
          budget: 12000,
          image: "/placeholder.svg?height=300&width=400",
          tags: ["heritage", "history", "culture"],
        },
        {
          title: "Nature Retreat in Coorg and Chikmagalur",
          description: "Experience the lush coffee plantations, misty hills, and waterfalls in the Western Ghats.",
          days: 5,
          budget: 15000,
          image: "/placeholder.svg?height=300&width=400",
          tags: ["nature", "wildlife", "trekking"],
        },
        {
          title: "Coastal Adventure in Gokarna and Murudeshwar",
          description: "Enjoy pristine beaches, water sports, and the spiritual ambiance of coastal Karnataka.",
          days: 3,
          budget: 8000,
          image: "/placeholder.svg?height=300&width=400",
          tags: ["adventure", "beaches", "spiritual"],
        },
      ]

      setRecommendations(mockRecommendations)
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 text-center">AI-Powered Travel Recommendations</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Form */}
        <Card className="lg:col-span-1">
          <CardContent className="p-6 space-y-6">
            <div className="space-y-2">
              <Label htmlFor="query">What are you looking for?</Label>
              <Input
                id="query"
                placeholder="E.g., Family trip with cultural experiences"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Budget per person (₹): {budget[0].toLocaleString()}</Label>
              <Slider min={1000} max={50000} step={1000} value={budget} onValueChange={setBudget} />
            </div>

            <div className="space-y-2">
              <Label>Number of days: {days[0]}</Label>
              <Slider min={1} max={15} step={1} value={days} onValueChange={setDays} />
            </div>

            <div className="space-y-3">
              <Label>Interests</Label>
              <div className="grid grid-cols-2 gap-2">
                {interestOptions.map((option) => (
                  <div key={option.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={option.id}
                      checked={interests.includes(option.id)}
                      onCheckedChange={() => toggleInterest(option.id)}
                    />
                    <Label htmlFor={option.id} className="text-sm">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <Button
              className="w-full bg-orange-500 hover:bg-orange-600"
              onClick={getRecommendations}
              disabled={loading}
            >
              {loading ? "Generating Recommendations..." : "Get Recommendations"}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="lg:col-span-2">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-64">
              <div className="w-16 h-16 border-4 border-t-orange-500 border-orange-200 rounded-full animate-spin"></div>
              <p className="mt-4 text-gray-600">Our AI is crafting perfect recommendations for you...</p>
            </div>
          ) : recommendations ? (
            <div className="space-y-6">
              {recommendations.map((rec, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/3">
                      <img
                        src={rec.image || "/placeholder.svg"}
                        alt={rec.title}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <CardContent className="p-6 md:w-2/3">
                      <h3 className="text-xl font-bold mb-2">{rec.title}</h3>
                      <p className="text-gray-600 mb-4">{rec.description}</p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {rec.tags.map((tag: string, i: number) => (
                          <span
                            key={i}
                            className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-xs font-medium"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                      <div className="flex justify-between items-center">
                        <div className="text-sm text-gray-500">
                          <span className="font-medium">{rec.days} days</span> • Budget: ₹{rec.budget.toLocaleString()}{" "}
                          per person
                        </div>
                        <Button variant="outline" className="border-orange-500 text-orange-500 hover:bg-orange-50">
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <img src="/placeholder.svg?height=150&width=150" alt="AI Recommendations" className="opacity-50 mb-4" />
              <p className="text-gray-500">
                Fill in your preferences and our AI will suggest the perfect Karnataka experiences for you
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
