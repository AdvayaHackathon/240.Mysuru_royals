import Link from "next/link"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import LanguageSwitcher from "@/components/language-switcher"
import FeaturedDestinations from "@/components/featured-destinations"
import HeroSection from "@/components/hero-section"

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {/* Search and Language */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <div className="relative w-full md:w-1/2 mb-6 md:mb-0">
            <div className="relative">
              <input
                type="text"
                placeholder="Search destinations, activities, or cultural experiences..."
                className="w-full p-4 pl-12 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          </div>
          <LanguageSwitcher />
        </div>

        {/* Featured Destinations */}
        <section className="mb-16">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800">Featured Destinations</h2>
            <Link href="/destinations">
              <Button variant="outline" className="border-orange-500 text-orange-500 hover:bg-orange-50">
                View All
              </Button>
            </Link>
          </div>
          <FeaturedDestinations />
        </section>

        {/* Quick Access Cards */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="h-40 bg-orange-100 rounded-lg mb-4 flex items-center justify-center">
                <img src="/placeholder.svg?height=160&width=320" alt="Budget Planner" className="h-32 object-contain" />
              </div>
              <h3 className="text-xl font-bold mb-2">Budget Planner</h3>
              <p className="text-gray-600 mb-4">Plan your Karnataka trip with our dynamic budget calculator.</p>
              <Link href="/budget-planner">
                <Button className="w-full bg-orange-500 hover:bg-orange-600">Plan Your Budget</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="h-40 bg-green-100 rounded-lg mb-4 flex items-center justify-center">
                <img
                  src="/placeholder.svg?height=160&width=320"
                  alt="Cultural Experiences"
                  className="h-32 object-contain"
                />
              </div>
              <h3 className="text-xl font-bold mb-2">Cultural Experiences</h3>
              <p className="text-gray-600 mb-4">Discover the rich cultural heritage and traditions of Karnataka.</p>
              <Link href="/culture">
                <Button className="w-full bg-green-600 hover:bg-green-700">Explore Culture</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="h-40 bg-blue-100 rounded-lg mb-4 flex items-center justify-center">
                <img
                  src="/placeholder.svg?height=160&width=320"
                  alt="AI Recommendations"
                  className="h-32 object-contain"
                />
              </div>
              <h3 className="text-xl font-bold mb-2">AI Recommendations</h3>
              <p className="text-gray-600 mb-4">Get personalized travel suggestions based on your preferences.</p>
              <Link href="/recommendations">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Get Recommendations</Button>
              </Link>
            </CardContent>
          </Card>
        </section>

        {/* Upcoming Festivals */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">Upcoming Festivals</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "Dasara", date: "October 15-24, 2023", location: "Mysuru" },
              { name: "Hampi Utsav", date: "November 3-5, 2023", location: "Hampi" },
              { name: "Kadalekai Parishe", date: "December 5-6, 2023", location: "Bengaluru" },
              { name: "Pattadakal Dance Festival", date: "January 20-22, 2024", location: "Pattadakal" },
            ].map((festival, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg mb-1">{festival.name}</h3>
                  <p className="text-gray-600 text-sm mb-1">{festival.date}</p>
                  <p className="text-orange-600 text-sm">{festival.location}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
