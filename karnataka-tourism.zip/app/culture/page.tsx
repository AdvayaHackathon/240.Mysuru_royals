import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CulturePage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 text-center">Cultural Heritage of Karnataka</h1>

      <Tabs defaultValue="festivals" className="mb-12">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="festivals">Festivals</TabsTrigger>
          <TabsTrigger value="cuisine">Cuisine</TabsTrigger>
          <TabsTrigger value="arts">Arts & Crafts</TabsTrigger>
          <TabsTrigger value="traditions">Traditions</TabsTrigger>
        </TabsList>

        {/* Festivals Tab */}
        <TabsContent value="festivals" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                name: "Mysuru Dasara",
                description:
                  "A 10-day celebration of the victory of good over evil, featuring a grand procession with decorated elephants, cultural performances, and the illuminated Mysore Palace.",
                image: "/placeholder.svg?height=300&width=500",
                location: "Mysuru",
                time: "September-October",
              },
              {
                name: "Hampi Utsav",
                description:
                  "A vibrant celebration of the rich cultural heritage of Vijayanagara Empire with music, dance, processions, fireworks, and puppet shows against the backdrop of ancient ruins.",
                image: "/placeholder.svg?height=300&width=500",
                location: "Hampi",
                time: "November",
              },
              {
                name: "Pattadakal Dance Festival",
                description:
                  "A classical dance festival held at the UNESCO World Heritage Site featuring performances by renowned artists in Bharatanatyam, Kuchipudi, Kathak, and Odissi.",
                image: "/placeholder.svg?height=300&width=500",
                location: "Pattadakal",
                time: "January",
              },
              {
                name: "Karaga",
                description:
                  "One of Bengaluru's oldest festivals, where the priest carries a flower pyramid on his head and leads a procession through the city, symbolizing the spirit of Draupadi.",
                image: "/placeholder.svg?height=300&width=500",
                location: "Bengaluru",
                time: "March-April",
              },
            ].map((festival, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="md:flex">
                  <div className="md:w-2/5">
                    <img
                      src={festival.image || "/placeholder.svg"}
                      alt={festival.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6 md:w-3/5">
                    <h3 className="text-xl font-bold mb-2">{festival.name}</h3>
                    <div className="flex items-center text-sm text-gray-500 mb-4">
                      <span className="mr-4">{festival.location}</span>
                      <span>{festival.time}</span>
                    </div>
                    <p className="text-gray-700">{festival.description}</p>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Cuisine Tab */}
        <TabsContent value="cuisine" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Mysore Pak",
                description:
                  "A rich sweet made from gram flour, ghee, and sugar, originating from the royal kitchens of Mysore Palace.",
                image: "/placeholder.svg?height=250&width=250",
                region: "Mysuru",
              },
              {
                name: "Bisi Bele Bath",
                description:
                  "A spicy, hot rice dish with lentils, vegetables, and a special spice powder, typically served with papad.",
                image: "/placeholder.svg?height=250&width=250",
                region: "South Karnataka",
              },
              {
                name: "Pandi Curry",
                description:
                  "A spicy pork curry from Coorg, made with a special blend of spices and Kachampuli (a souring agent).",
                image: "/placeholder.svg?height=250&width=250",
                region: "Coorg",
              },
              {
                name: "Neer Dosa",
                description:
                  "A thin, soft, and delicate rice crepe from coastal Karnataka, typically served with coconut chutney or curry.",
                image: "/placeholder.svg?height=250&width=250",
                region: "Coastal Karnataka",
              },
              {
                name: "Dharwad Peda",
                description: "A sweet delicacy made from milk and sugar, known for its unique taste and texture.",
                image: "/placeholder.svg?height=250&width=250",
                region: "Dharwad",
              },
              {
                name: "Ragi Mudde",
                description:
                  "A staple food made from finger millet flour, typically served with Bassaru (a lentil-based curry).",
                image: "/placeholder.svg?height=250&width=250",
                region: "Rural Karnataka",
              },
            ].map((dish, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="h-48 overflow-hidden">
                  <img src={dish.image || "/placeholder.svg"} alt={dish.name} className="w-full h-full object-cover" />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold mb-1">{dish.name}</h3>
                  <p className="text-sm text-orange-600 mb-2">{dish.region}</p>
                  <p className="text-gray-600">{dish.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Arts & Crafts Tab */}
        <TabsContent value="arts" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                name: "Mysore Painting",
                description:
                  "Traditional paintings characterized by the use of gold foil, depicting Hindu gods, goddesses, and mythological scenes.",
                image: "/placeholder.svg?height=300&width=500",
                origin: "Mysuru",
              },
              {
                name: "Bidriware",
                description:
                  "Metal handicraft from Bidar that involves inlaying silver wire on blackened metal alloy, creating intricate designs.",
                image: "/placeholder.svg?height=300&width=500",
                origin: "Bidar",
              },
              {
                name: "Channapatna Toys",
                description:
                  "Colorful wooden toys and dolls made using ivory wood and vegetable dyes, known as 'toys of the toy-land'.",
                image: "/placeholder.svg?height=300&width=500",
                origin: "Channapatna",
              },
              {
                name: "Kasuti Embroidery",
                description:
                  "Traditional form of folk embroidery with intricate patterns that are sewn without knots, typically on Ilkal sarees.",
                image: "/placeholder.svg?height=300&width=500",
                origin: "North Karnataka",
              },
            ].map((art, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="md:flex">
                  <div className="md:w-2/5">
                    <img src={art.image || "/placeholder.svg"} alt={art.name} className="h-full w-full object-cover" />
                  </div>
                  <CardContent className="p-6 md:w-3/5">
                    <h3 className="text-xl font-bold mb-2">{art.name}</h3>
                    <p className="text-sm text-blue-600 mb-4">{art.origin}</p>
                    <p className="text-gray-700">{art.description}</p>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Traditions Tab */}
        <TabsContent value="traditions" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                name: "Yakshagana",
                description:
                  "A traditional theater form combining dance, music, dialogue, costume, make-up, and stage techniques with a unique style and form.",
                image: "/placeholder.svg?height=300&width=500",
                region: "Coastal Karnataka",
              },
              {
                name: "Dollu Kunitha",
                description:
                  "A drum dance performed with large drums hung around the neck, accompanied by singing and rhythmic movements.",
                image: "/placeholder.svg?height=300&width=500",
                region: "Southern Karnataka",
              },
              {
                name: "Kamsale",
                description:
                  "A folk art form dedicated to Lord Mahadeshwara, where performers dance with cymbal-like instruments called Kamsale.",
                image: "/placeholder.svg?height=300&width=500",
                region: "Mysuru region",
              },
              {
                name: "Kodava Traditions",
                description:
                  "Unique customs of the Kodava community including Kailpodh (festival of arms), traditional attire, and marriage ceremonies.",
                image: "/placeholder.svg?height=300&width=500",
                region: "Coorg",
              },
            ].map((tradition, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="md:flex">
                  <div className="md:w-2/5">
                    <img
                      src={tradition.image || "/placeholder.svg"}
                      alt={tradition.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6 md:w-3/5">
                    <h3 className="text-xl font-bold mb-2">{tradition.name}</h3>
                    <p className="text-sm text-green-600 mb-4">{tradition.region}</p>
                    <p className="text-gray-700">{tradition.description}</p>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Cultural Calendar */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold mb-8">Cultural Calendar 2023-2024</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead>
              <tr className="bg-gray-100">
                <th className="py-3 px-4 border-b text-left">Festival/Event</th>
                <th className="py-3 px-4 border-b text-left">Date</th>
                <th className="py-3 px-4 border-b text-left">Location</th>
                <th className="py-3 px-4 border-b text-left">Description</th>
              </tr>
            </thead>
            <tbody>
              {[
                {
                  name: "Mysuru Dasara",
                  date: "October 15-24, 2023",
                  location: "Mysuru",
                  description: "Grand celebration with processions and cultural events",
                },
                {
                  name: "Hampi Utsav",
                  date: "November 3-5, 2023",
                  location: "Hampi",
                  description: "Cultural festival celebrating the Vijayanagara Empire",
                },
                {
                  name: "Kadalekai Parishe",
                  date: "December 5-6, 2023",
                  location: "Bengaluru",
                  description: "Traditional groundnut fair at Bull Temple",
                },
                {
                  name: "Pattadakal Dance Festival",
                  date: "January 20-22, 2024",
                  location: "Pattadakal",
                  description: "Classical dance performances at UNESCO site",
                },
                {
                  name: "Karaga Festival",
                  date: "April 5-15, 2024",
                  location: "Bengaluru",
                  description: "Ancient festival honoring Draupadi",
                },
                {
                  name: "Tula Sankramana",
                  date: "October 17, 2023",
                  location: "Talakaveri",
                  description: "Ritual bathing at the source of River Cauvery",
                },
              ].map((event, index) => (
                <tr key={index} className={index % 2 === 0 ? "bg-gray-50" : ""}>
                  <td className="py-3 px-4 border-b">{event.name}</td>
                  <td className="py-3 px-4 border-b">{event.date}</td>
                  <td className="py-3 px-4 border-b">{event.location}</td>
                  <td className="py-3 px-4 border-b">{event.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Phrasebook */}
      <section>
        <h2 className="text-2xl font-bold mb-8">Kannada Phrasebook for Travelers</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { english: "Hello", kannada: "ನಮಸ್ಕಾರ", pronunciation: "Namaskara" },
            { english: "Thank you", kannada: "ಧನ್ಯವಾದಗಳು", pronunciation: "Dhanyavadagalu" },
            { english: "Yes", kannada: "ಹೌದು", pronunciation: "Haudu" },
            { english: "No", kannada: "ಇಲ್ಲ", pronunciation: "Illa" },
            { english: "How much?", kannada: "ಎಷ್ಟು?", pronunciation: "Eshtu?" },
            { english: "Where is...?", kannada: "ಎಲ್ಲಿದೆ...?", pronunciation: "Ellide...?" },
            { english: "I don't understand", kannada: "ನನಗೆ ಅರ್ಥವಾಗುತ್ತಿಲ್ಲ", pronunciation: "Nanage arthavaguthilla" },
            { english: "Good morning", kannada: "ಶುಭೋದಯ", pronunciation: "Shubhodaya" },
            { english: "Good night", kannada: "ಶುಭ ರಾತ್ರಿ", pronunciation: "Shubha Ratri" },
          ].map((phrase, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <p className="text-lg font-bold text-gray-800">{phrase.english}</p>
                <p className="text-xl my-2 text-orange-600">{phrase.kannada}</p>
                <p className="text-sm text-gray-600">Pronunciation: {phrase.pronunciation}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
