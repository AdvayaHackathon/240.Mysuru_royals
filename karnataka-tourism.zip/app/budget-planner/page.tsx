"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { useLanguage } from "@/context/language-context"

export default function BudgetPlanner() {
  const { t } = useLanguage()
  const [travelers, setTravelers] = useState(2)
  const [days, setDays] = useState(5)
  const [travelMode, setTravelMode] = useState("road")
  const [accommodation, setAccommodation] = useState("mid-range")
  const [budget, setBudget] = useState<null | {
    travel: number
    accommodation: number
    food: number
    activities: number
    total: number
  }>(null)

  const calculateBudget = () => {
    // Base costs per person per day in INR
    const baseCosts = {
      travel: {
        road: 500,
        rail: 800,
        air: 2500,
      },
      accommodation: {
        budget: 1000,
        "mid-range": 2500,
        luxury: 6000,
      },
      food: {
        budget: 500,
        "mid-range": 1000,
        luxury: 2000,
      },
      activities: {
        budget: 300,
        "mid-range": 800,
        luxury: 1500,
      },
    }

    // Calculate costs
    const travelCost = baseCosts.travel[travelMode as keyof typeof baseCosts.travel] * travelers
    const accommodationCost =
      baseCosts.accommodation[accommodation as keyof typeof baseCosts.accommodation] * travelers * days
    const foodCost = baseCosts.food[accommodation as keyof typeof baseCosts.food] * travelers * days
    const activitiesCost = baseCosts.activities[accommodation as keyof typeof baseCosts.activities] * travelers * days

    const totalCost = travelCost + accommodationCost + foodCost + activitiesCost

    setBudget({
      travel: travelCost,
      accommodation: accommodationCost,
      food: foodCost,
      activities: activitiesCost,
      total: totalCost,
    })
  }

  const downloadPDF = () => {
    // In a real app, this would generate a PDF
    alert("In a production app, this would generate a downloadable PDF of your budget plan.")
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8 text-center">Dynamic Budget Planner</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <Card>
          <CardHeader>
            <CardTitle>Plan Your Trip Budget</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Number of Travelers */}
            <div className="space-y-2">
              <Label htmlFor="travelers">Number of Travelers: {travelers}</Label>
              <Slider
                id="travelers"
                min={1}
                max={10}
                step={1}
                value={[travelers]}
                onValueChange={(value) => setTravelers(value[0])}
              />
            </div>

            {/* Number of Days */}
            <div className="space-y-2">
              <Label htmlFor="days">Number of Days: {days}</Label>
              <Slider id="days" min={1} max={15} step={1} value={[days]} onValueChange={(value) => setDays(value[0])} />
            </div>

            {/* Travel Mode */}
            <div className="space-y-2">
              <Label>Travel Mode</Label>
              <RadioGroup value={travelMode} onValueChange={setTravelMode} className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="road" id="road" />
                  <Label htmlFor="road">Road</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="rail" id="rail" />
                  <Label htmlFor="rail">Rail</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="air" id="air" />
                  <Label htmlFor="air">Air</Label>
                </div>
              </RadioGroup>
            </div>

            {/* Accommodation Type */}
            <div className="space-y-2">
              <Label htmlFor="accommodation">Accommodation Type</Label>
              <Select value={accommodation} onValueChange={setAccommodation}>
                <SelectTrigger id="accommodation">
                  <SelectValue placeholder="Select accommodation type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="budget">Budget</SelectItem>
                  <SelectItem value="mid-range">Mid-Range</SelectItem>
                  <SelectItem value="luxury">Luxury</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Calculate Button */}
            <Button className="w-full bg-orange-500 hover:bg-orange-600" onClick={calculateBudget}>
              Calculate Budget
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        <Card>
          <CardHeader>
            <CardTitle>Estimated Budget</CardTitle>
          </CardHeader>
          <CardContent>
            {budget ? (
              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b pb-2">
                    <span className="font-medium">Travel:</span>
                    <span>₹{budget.travel.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center border-b pb-2">
                    <span className="font-medium">Accommodation:</span>
                    <span>₹{budget.accommodation.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center border-b pb-2">
                    <span className="font-medium">Food:</span>
                    <span>₹{budget.food.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center border-b pb-2">
                    <span className="font-medium">Activities:</span>
                    <span>₹{budget.activities.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 text-lg font-bold">
                    <span>Total Estimated Cost:</span>
                    <span className="text-orange-600">₹{budget.total.toLocaleString()}</span>
                  </div>
                </div>

                <div className="pt-4">
                  <Button className="w-full" variant="outline" onClick={downloadPDF}>
                    Download as PDF
                  </Button>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg mt-6">
                  <h3 className="font-bold mb-2">Budget Tips</h3>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>Off-season travel can reduce costs by up to 30%</li>
                    <li>Consider homestays in Coorg and Chikmagalur for authentic experiences</li>
                    <li>KSRTC buses offer economical transportation between major cities</li>
                    <li>Many heritage sites offer discounted tickets for online booking</li>
                  </ul>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <p className="text-gray-500 mb-4">
                  Fill in your trip details and click Calculate to see your estimated budget
                </p>
                <img src="/placeholder.svg?height=150&width=150" alt="Budget Calculator" className="opacity-50" />
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
