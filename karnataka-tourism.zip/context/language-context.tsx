"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

type LanguageType = "en" | "kn" | "hi" | "ta"

interface LanguageContextType {
  language: LanguageType
  setLanguage: (language: LanguageType) => void
  translations: Record<string, Record<string, string>>
  t: (key: string) => string
}

const defaultTranslations = {
  en: {
    welcome: "Welcome to Karnataka Tourism",
    explore: "Explore Destinations",
    planBudget: "Plan Your Budget",
  },
  kn: {
    welcome: "ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮಕ್ಕೆ ಸುಸ್ವಾಗತ",
    explore: "ತಾಣಗಳನ್ನು ಅನ್ವೇಷಿಸಿ",
    planBudget: "ನಿಮ್ಮ ಬಜೆಟ್ ಯೋಜಿಸಿ",
  },
  hi: {
    welcome: "कर्नाटक पर्यटन में आपका स्वागत है",
    explore: "गंतव्यों का अन्वेषण करें",
    planBudget: "अपना बजट योजना बनाएं",
  },
  ta: {
    welcome: "கர்நாடக சுற்றுலாவிற்கு வரவேற்கிறோம்",
    explore: "இடங்களை ஆராயுங்கள்",
    planBudget: "உங்கள் பட்ஜெட்டை திட்டமிடுங்கள்",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<LanguageType>("en")
  const [translations] = useState(defaultTranslations)

  const t = (key: string): string => {
    return translations[language]?.[key] || translations.en[key] || key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, translations, t }}>{children}</LanguageContext.Provider>
  )
}

export function useLanguage(): LanguageContextType {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
