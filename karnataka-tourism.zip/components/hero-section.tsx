"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useLanguage } from "@/context/language-context"

export default function HeroSection() {
  const { t } = useLanguage()

  return (
    <div className="relative h-[80vh] overflow-hidden">
      {/* Hero Image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('/placeholder.svg?height=1080&width=1920')",
          filter: "brightness(0.7)",
        }}
      />

      {/* Content */}
      <div className="relative h-full flex flex-col items-center justify-center text-center px-4">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">{t("welcome")}</h1>
        <p className="text-xl md:text-2xl text-white mb-8 max-w-3xl">
          From ancient temples to lush forests, experience the rich cultural heritage and natural beauty
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link href="/destinations">
            <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-6 text-lg">
              {t("explore")}
            </Button>
          </Link>
          <Link href="/budget-planner">
            <Button
              size="lg"
              variant="outline"
              className="bg-white/10 backdrop-blur-sm border-white text-white hover:bg-white/20 px-8 py-6 text-lg"
            >
              {t("planBudget")}
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
