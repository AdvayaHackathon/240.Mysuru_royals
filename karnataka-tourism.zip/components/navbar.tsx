"use client"

import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import LanguageSwitcher from "./language-switcher"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold text-orange-600">Karnataka Tourism</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/destinations" className="text-gray-700 hover:text-orange-500 font-medium">
              Destinations
            </Link>
            <Link href="/culture" className="text-gray-700 hover:text-orange-500 font-medium">
              Culture
            </Link>
            <Link href="/budget-planner" className="text-gray-700 hover:text-orange-500 font-medium">
              Budget Planner
            </Link>
            <Link href="/recommendations" className="text-gray-700 hover:text-orange-500 font-medium">
              AI Recommendations
            </Link>
            <LanguageSwitcher />
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={toggleMenu}>
              {isMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white py-4 px-4 shadow-md">
          <nav className="flex flex-col space-y-4">
            <Link
              href="/destinations"
              className="text-gray-700 hover:text-orange-500 font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Destinations
            </Link>
            <Link
              href="/culture"
              className="text-gray-700 hover:text-orange-500 font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Culture
            </Link>
            <Link
              href="/budget-planner"
              className="text-gray-700 hover:text-orange-500 font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Budget Planner
            </Link>
            <Link
              href="/recommendations"
              className="text-gray-700 hover:text-orange-500 font-medium py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              AI Recommendations
            </Link>
            <div className="py-2">
              <LanguageSwitcher />
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
