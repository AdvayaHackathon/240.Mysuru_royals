import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

const destinations = [
  {
    id: "mysuru",
    name: "Mysuru",
    image: "/placeholder.svg?height=300&width=400",
    description: "The cultural capital with the magnificent Mysore Palace",
  },
  {
    id: "hampi",
    name: "Hampi",
    image: "/placeholder.svg?height=300&width=400",
    description: "UNESCO World Heritage Site with ancient ruins",
  },
  {
    id: "coorg",
    name: "Coorg",
    image: "/placeholder.svg?height=300&width=400",
    description: "Lush green hills and coffee plantations",
  },
  {
    id: "gokarna",
    name: "Gokarna",
    image: "/placeholder.svg?height=300&width=400",
    description: "Pristine beaches and spiritual temples",
  },
  {
    id: "chikmagalur",
    name: "Chikmagalur",
    image: "/placeholder.svg?height=300&width=400",
    description: "Coffee estates and beautiful mountain ranges",
  },
  {
    id: "badami",
    name: "Badami",
    image: "/placeholder.svg?height=300&width=400",
    description: "Ancient cave temples and historical sites",
  },
]

export default function FeaturedDestinations() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {destinations.map((destination) => (
        <Link href={`/destinations/${destination.id}`} key={destination.id}>
          <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full">
            <div className="h-48 overflow-hidden">
              <img
                src={destination.image || "/placeholder.svg"}
                alt={destination.name}
                className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
              />
            </div>
            <CardContent className="p-4">
              <h3 className="text-xl font-bold mb-2">{destination.name}</h3>
              <p className="text-gray-600">{destination.description}</p>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
