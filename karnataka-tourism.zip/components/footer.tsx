import Link from "next/link"
import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-bold mb-4">Karnataka Tourism</h3>
            <p className="text-gray-300 mb-4">
              Discover the rich cultural heritage and natural beauty of Karnataka, India.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-300 hover:text-white">
                <Facebook size={20} />
              </Link>
              <Link href="#" className="text-gray-300 hover:text-white">
                <Twitter size={20} />
              </Link>
              <Link href="#" className="text-gray-300 hover:text-white">
                <Instagram size={20} />
              </Link>
              <Link href="#" className="text-gray-300 hover:text-white">
                <Youtube size={20} />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/destinations" className="text-gray-300 hover:text-white">
                  Destinations
                </Link>
              </li>
              <li>
                <Link href="/culture" className="text-gray-300 hover:text-white">
                  Cultural Heritage
                </Link>
              </li>
              <li>
                <Link href="/budget-planner" className="text-gray-300 hover:text-white">
                  Budget Planner
                </Link>
              </li>
              <li>
                <Link href="/recommendations" className="text-gray-300 hover:text-white">
                  AI Recommendations
                </Link>
              </li>
            </ul>
          </div>

          {/* Popular Destinations */}
          <div>
            <h3 className="text-xl font-bold mb-4">Popular Destinations</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/destinations/mysuru" className="text-gray-300 hover:text-white">
                  Mysuru
                </Link>
              </li>
              <li>
                <Link href="/destinations/hampi" className="text-gray-300 hover:text-white">
                  Hampi
                </Link>
              </li>
              <li>
                <Link href="/destinations/coorg" className="text-gray-300 hover:text-white">
                  Coorg
                </Link>
              </li>
              <li>
                <Link href="/destinations/gokarna" className="text-gray-300 hover:text-white">
                  Gokarna
                </Link>
              </li>
              <li>
                <Link href="/destinations/bengaluru" className="text-gray-300 hover:text-white">
                  Bengaluru
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Us</h3>
            <address className="not-italic text-gray-300 space-y-2">
              <p>Department of Tourism</p>
              <p>Government of Karnataka</p>
              <p>Bengaluru, Karnataka</p>
              <p>India - 560001</p>
              <p className="mt-2">Email: info@karnataka-tourism.org</p>
              <p>Phone: +91 80 2235 2828</p>
            </address>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p>© {new Date().getFullYear()} Karnataka Tourism. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
